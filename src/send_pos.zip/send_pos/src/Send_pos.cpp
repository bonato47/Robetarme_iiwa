#include "ros/ros.h"
#include "sensor_msgs/JointState.h"
#include "vector"
#include "std_msgs/Float64MultiArray.h"

#include <sstream>


void CounterCallback(const sensor_msgs::JointState::ConstPtr& msg)
{
  ROS_INFO("%d", msg->header.seq);
  ROS_INFO("%s", msg->header.frame_id.c_str());
  //ROS_INFO("%s", msg->header.stamp);
  //ROS_INFO("%lf", msg->position);
  //ROS_INFO("%f", msg->velocity);
  //ROS_INFO("%f", msg->effort);
  std::vector<double> pos = msg->position;
  std::vector<double> vel = msg->velocity;
  std::vector<double> eff = msg->effort;

  std::cout<< "pos = {";
  for (double P : pos)
    std::cout<< P << ",";
  std::cout << "}:/n";

  std::cout<< "vel = {";
  for (double V : vel)
    std::cout<< V << ",";
  std::cout << "}:/n";

  std::cout<< "eff = {";
  for (double E : eff)
    std::cout<< E << ",";
  std::cout << "}:/n";
  

}

int main(int argc, char **argv)
{

  ros::init(argc, argv, "Send_pos");


  ros::NodeHandle n;

  //ros::Subscriber sub = n.subscribe("iiwa/joint_states", 1000, CounterCallback);
  ros::Publisher chatter_pub = n.advertise<std_msgs::Float64MultiArray>("iiwa/PositionController/command", 1000);

  ros::Rate loop_rate(10);
  int count = 0;

  while (ros::ok())
  {
    std_msgs::Float64MultiArray msgP;
    msgP.data = {0,0,0,0,0,0,0};

    chatter_pub.publish(msgP);

    ros::spinOnce();

    loop_rate.sleep();
    ++count;
  }
  return 0;
   
}